# Project 2: Shiny App Development Version 2.0
### App folder

The App directory contains the app files for the Shiny App (i.e., ui.r and server.r).

